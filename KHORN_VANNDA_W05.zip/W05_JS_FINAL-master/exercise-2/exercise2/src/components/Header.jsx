function Header(){
    return(
        <header class="block">
        <h1>Welcome again !</h1>
        <p></p>
      </header>
    );
}
export default Header